# AIH policy review packet — 2026-09-01

This packet preserves the drafted organization policy, a minimally corrected candidate,
the three-item artifact intake, Scanner evidence, and public `@aihq/core@0.4.3`
validation/evaluation reports. It is an administrator review packet, not authority and
not permission to install, activate, or project an artifact.

## Workbench import order

Run the released `next` version explicitly because npm `latest` currently points to
`0.3.0`:

```powershell
npx @aihq/core@0.4.3 --ui
```

In the Workbench:

1. Import `aih-org-policy.corrected.json` as the policy.
2. Import `aih-artifact-intake.json` in **Artifacts**.
3. Merge `aih-artifact-evidence.json` in **Artifacts**.

The import order matters: replacing the policy clears the in-memory artifact review
queue, so policy import must come first.

## Policy status

- Both the original and corrected policy pass the public `0.4.3` Enterprise schema
  validator.
- The original policy selected five managed MCP activations but omitted the required
  managed-MCP allowlist.
- `aih-org-policy.corrected.json` adds `mcp.allowManagedOnly: true` and an exact
  `allowedServers` list for the five selected managed MCPs. No original selection was
  removed and the original file is retained unchanged.
- All 11 supported CLI identifiers are explicitly sanctioned.
- The ECC selection contains 97 unique pinned items and 52 roots. Every root resolves
  to an item, and every selected path exists in
  `samartomar/ECC@5caf398a91599029a176ca6d806409b00d1052c4`.
- The corrected policy is not yet safe to project in a clean target. Public `0.4.3`
  evaluation still reports missing managed-MCP ownership, Context7 has no projectable
  runtime entry, and Playwright has identity drift plus missing authority/evidence.

Do not run `aih policy project --apply` until effective evaluation passes in the real
target and the required ownership/authority receipts exist.

## New artifact evidence status

| Item | Observed state | Result |
|---|---|---|
| Grill Me Skill | Exact GitHub commit and `SKILL.md` path; verified native preflight | May continue to protected administrator approval after replacing the placeholder accountable owner and supplying genuine organization authority, targets, effects, and evidence envelope data. |
| Firecrawl MCP `firecrawl-mcp@3.24.0` | Exact npm tarball observed; enterprise scan failed | Blocked. Direct dependencies use unpinned ranges and no lockfile is present. Optional deep analyzers were also unavailable locally; no approval or activation was created. |
| Atlassian Jira & Confluence MCP | Pulse claim corroborated with official MCP Registry record `com.atlassian/atlassian-mcp-server@1.1.3` | Resolution only. The registry exposes two hosted streamable-HTTP endpoints, not a scannable package/source. Remote evidence/administrative authority is still required. |

The Workbench round trip was exercised with the corrected policy, intake, and evidence.
It displayed `Verified preflight` for Grill Me, `Failed scan evidence` for Firecrawl,
and `Directory resolved · Scan still required` for Atlassian.

## Evidence identities

- Intake SHA-256: `111E16DFC9B0BB7601DDD84AD48433A4AF8C03B1D30C29D2E9F8A2085820AC82`
- Evidence file SHA-256: `2908F53A64B4C1C1FAFFE3B1585E105D8F40952EDF6817B52CB5B47CB97A42F1`
- Evidence bundle digest: `sha256:bb2d4cd5e5bf47aefbb0966041f284ff4cf9bbd1f2beb47325fd2beb697c2208`
- Grill Me evidence: `scan-grill-me-82505a5f3704`
- Firecrawl evidence: `scan-firecrawl-mcp-9d69936c9b6c`
- Atlassian resolution: `resolve-atlassian-72c7e638a768`

`SHA256SUMS.txt` covers every packet artifact other than itself.
